﻿namespace Allivet.Test.Service.Contracts
{
    public interface IParser
    {
        Task<string> ParseContent(string url);
    }
}