﻿function parseUrlContent() {
    let urlToParse = $("#txtURL").val();
    let parserURL = window.location.origin + "/parser/ParseURLContent?url=" + urlToParse;
    $.ajax({
        url: parserURL,
        type: 'GET',
        dataType: 'json',
        success: function (res) {
            debugger;
            $("#downloadFile").trigger("click");
            console.log(res);
            alert(res);
        }
    });
}