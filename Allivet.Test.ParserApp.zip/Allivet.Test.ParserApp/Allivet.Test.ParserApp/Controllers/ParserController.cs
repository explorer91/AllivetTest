﻿using Allivet.Test.Service.Contracts;
using Microsoft.AspNetCore.Mvc;

namespace Allivet.Test.ParserApp.Controllers
{
    public class ParserController : Controller
    {
        private readonly IParser _parser;

        public ParserController(IParser parser)
        {
            _parser = parser;
        }
        [HttpGet]
        public async Task<JsonResult> ParseURLContent([FromQuery] string url)
        {
            await _parser.ParseContent(url);
            return Json(new { Parserd = true });
        }

    }
}
